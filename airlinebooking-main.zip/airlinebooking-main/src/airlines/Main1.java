package airlines;
public class Main1 {
	
	public static String User_id;

	public static void main(String u)
	{
		User_id = u;
		MyBDemo.main(null);
	}
	
}

