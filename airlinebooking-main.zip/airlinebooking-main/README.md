# airlinebooking
Its a airline booking stand alone application. The main features of this application are we can search and sort thing easily and comfortably. We made a OTP login feature.
Developed this application as a team of four:
- 2019A7PS0014H - Simhadri Surya Kiran.
- 2019A7PS0061H - Madepalli Balu Pavan.
- 2019A7PS0067H - Guthula Baladhitya.
- 2019A7PS0093H - Chodisetti Rajesh
